$(window).on('load', function () {
  $('#preloader').fadeOut('slow');
});
